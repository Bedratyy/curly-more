---
title: Landing
layout: landing
description: 'Lorem ipsum dolor sit amet nullam consequa<br />sed veroeros. tempus adipiscing nulla.'
image: assets/images/pic07.jpg
nav-menu: true
---

<section id="banner" class="style2">
  <div class="inner">
  <span class="image">
  <img src="{{ site.baseurl }}/%7B%7B%20page.image%20%7D%7D" alt="">
</span>
  <header class="major">

# Landing

</header>
  <div class="content">

{{ page.description }}

</div>
</div>
</section>

<div id="main">
  <section id="one">
  <div class="inner"><header class="major">

## Sed amet aliquam

</header>

Nullam et orci eu lorem consequat tincidunt vivamus et sagittis magna sed nunc rhoncus condimentum sem. In efficitur ligula tate urna. Maecenas massa vel lacinia pellentesque lorem ipsum dolor. Nullam et orci eu lorem consequat tincidunt. Vivamus et sagittis libero. Nullam et orci eu lorem consequat tincidunt vivamus et sagittis magna sed nunc rhoncus condimentum sem. In efficitur ligula tate urna.

</div>
  <p></p>
</section>
  <p>
</p>
  <section id="two" class="spotlights">
  <section><a href="generic.html">
  <img src="assets/images/pic08.jpg" alt="" data-position="center center">
</a>{:.image}

<div class="content">
  <div class="inner"><header class="major">

### Orci maecenas

</header>

Nullam et orci eu lorem consequat tincidunt vivamus et sagittis magna sed nunc rhoncus condimentum sem. In efficitur ligula tate urna. Maecenas massa sed magna lacinia magna pellentesque lorem ipsum dolor. Nullam et orci eu lorem consequat tincidunt. Vivamus et sagittis tempus.

<em><a href="generic.html">Learn more</a>{:.button}

</em></div>
  <em></em>
</div></section>
  <em></em>
  <section>
  <em><a href="generic.html"><img src="assets/images/pic09.jpg" alt="" data-position="top center"></a>{:.image}

</em>
  <div class="content">
  <em></em>
  <div class="inner"><em><header class="major">

### Rhoncus magna

</header>

Nullam et orci eu lorem consequat tincidunt vivamus et sagittis magna sed nunc rhoncus condimentum sem. In efficitur ligula tate urna. Maecenas massa sed magna lacinia magna pellentesque lorem ipsum dolor. Nullam et orci eu lorem consequat tincidunt. Vivamus et sagittis tempus.

</em>   <a href="generic.html">Learn more</a>{:.button}

</div>
</div>
</section>
  <section><a href="generic.html">
  <img src="assets/images/pic10.jpg" alt="" data-position="25% 25%">
</a>{:.image}

<div class="content">
  <div class="inner"><header class="major">

### Sed nunc ligula

</header>

Nullam et orci eu lorem consequat tincidunt vivamus et sagittis magna sed nunc rhoncus condimentum sem. In efficitur ligula tate urna. Maecenas massa sed magna lacinia magna pellentesque lorem ipsum dolor. Nullam et orci eu lorem consequat tincidunt. Vivamus et sagittis tempus.

<em><a href="generic.html">Learn more</a>{:.button}

</em></div>
  <em></em>
</div></section>
  <em><p></p></em>
</section>
  <em>
  <p></p>
</em>
  <section id="three">
  <em></em>
  <div class="inner"><em><header class="major">

## Massa libero

</header>

Nullam et orci eu lorem consequat tincidunt vivamus et sagittis libero. Mauris aliquet magna magna sed nunc rhoncus pharetra. Pellentesque condimentum sem. In efficitur ligula tate urna. Maecenas laoreet massa vel lacinia pellentesque lorem ipsum dolor. Nullam et orci eu lorem consequat tincidunt. Vivamus et sagittis libero. Mauris aliquet magna magna sed nunc rhoncus amet pharetra et feugiat tempus.

</em>   <a href="generic.html">Get Started</a>{:.button .next}

</div>
</section>
  <p>
</p>
</div>
